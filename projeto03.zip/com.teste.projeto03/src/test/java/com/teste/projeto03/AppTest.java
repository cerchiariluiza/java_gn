package com.teste.projeto03;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.teste.projeto03.model.Empregado;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * EmpregadoTeste: 2 Objetos da class Empregado - jUnit
     */
    @Test
    public void empregadoTeste()
    {
    	Empregado empregado01 = new Empregado();
    	empregado01.setNome("Gabriel");
    	empregado01.setSobrenome("Souza");
    	empregado01.setSalarioMensal(1000);
    	empregado01.exibirSalarioEmpregado();
    	Empregado empregado02 = new Empregado();
    	empregado02.setNome("Raiam");
    	empregado02.setSobrenome("Silva");
    	empregado02.setSalarioMensal(3555);
    	empregado02.exibirSalarioEmpregado();
    	
    	
    	
    }
}
