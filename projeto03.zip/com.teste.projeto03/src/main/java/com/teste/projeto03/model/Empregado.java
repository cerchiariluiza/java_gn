package com.teste.projeto03.model;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Empregado implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	private String nome;
	private String sobrenome;
	private double salarioMensal;
	
	public Empregado() {
		// TODO Auto-generated constructor stub
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public double getSalarioMensal() {
		return salarioMensal;
	}
	public void setSalarioMensal(double salarioMensal) {
		this.salarioMensal = salarioMensal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		long temp;
		temp = Double.doubleToLongBits(salarioMensal);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((sobrenome == null) ? 0 : sobrenome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empregado other = (Empregado) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (Double.doubleToLongBits(salarioMensal) != Double.doubleToLongBits(other.salarioMensal))
			return false;
		if (sobrenome == null) {
			if (other.sobrenome != null)
				return false;
		} else if (!sobrenome.equals(other.sobrenome))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Empregado [nome=" + nome + ", sobrenome=" + sobrenome + ", salarioMensal=" + salarioMensal + "]";
	}
	
	public void exibirSalarioEmpregado() {
		String salarioMensalFormatado = new DecimalFormat("#,##0.00").format(salarioMensal);
		System.out.println( nome + " Seu salário é: " + salarioMensalFormatado + " R$"); 
		double aumentoDezPorcento = (salarioMensal * 0.1);
		double salarioAtual = (aumentoDezPorcento + salarioMensal);
		String salarioAtualFormatado = new DecimalFormat("#,##0.00").format(salarioAtual);
		System.out.println("Parabéns " + nome + " " + sobrenome + ", Você recebeu um aumento de: " + aumentoDezPorcento + " R$");
		System.out.println("O seu salário atual é: " + salarioAtualFormatado + " R$");
		System.out.println("================================================");
	}
	 
	
}
