package com.teste.projeto02.com.teste.projeto02;


public class App 
{
    public static void main( String[] args )
    {
    	
    	IntergerSet s1 = new IntergerSet();
    	s1.insertElement(10);
    	s1.insertElement(20);
    	s1.insertElement(30);
    	s1.insertElement(40);
    	
    	IntergerSet s2 = new IntergerSet();
    	s2.insertElement(0);
    	s2.insertElement(20);
    	s2.insertElement(30);
    	s2.insertElement(45);
    	s2.deletElement(20);
    	
    	System.out.println("s1 = " + s1.toSetString());
    	System.out.println("s2 = " + s2.toSetString());
    	System.out.println("intersecção=" + s1.intersecction(s2).toSetString());
    	System.out.println("união=" + s1.union(s2).toSetString());
    	System.out.println("s1 e s2 iguais? " + s1.isEqualsTo(s2));
    	System.out.println("set vazio: " + new IntergerSet().toSetString());
    	
    	IntergerSet s3 = new IntergerSet();
    	s3.insertElement(30);
    	s3.insertElement(10);
    	s3.insertElement(20);
    	s3.insertElement(40);
    	System.out.println("s1 e s3 iguais? " + s1.isEqualsTo(s3));
    }
}
