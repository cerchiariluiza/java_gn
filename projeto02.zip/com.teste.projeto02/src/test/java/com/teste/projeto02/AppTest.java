package com.teste.projeto02;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.teste.projeto02.model.Fatura;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Método para testar a capacidade da fatura com junit
     */
	
    @Test
    public void faturaTeste()
    {
        Fatura faturaTeste = new Fatura();
        faturaTeste.setNumeroFatura("85412 8784554 8988998 9656655");
        faturaTeste.setDescricaoFatura("Suplemento whey protein");
        faturaTeste.setQuantidade(10);
        faturaTeste.setPrecoItem(-10D);
        faturaTeste.getTotalFatura();
        // Usa o method toString da class Fatura para mostrar os dados;
        System.out.println(faturaTeste);
    }
}
