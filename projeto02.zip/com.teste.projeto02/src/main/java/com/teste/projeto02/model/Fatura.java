package com.teste.projeto02.model;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Fatura implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String numeroFatura;
	private String descricaoFatura;
	private int quantidade;
	private Double precoItem;

	
	public Fatura() {
		
	}


	public String getNumeroFatura() {
		return numeroFatura;
	}


	public void setNumeroFatura(String numeroFatura) {
		this.numeroFatura = numeroFatura;
	}


	public String getDescricaoFatura() {
		return descricaoFatura;
	}


	public void setDescricaoFatura(String descricaoFatura) {
		this.descricaoFatura = descricaoFatura;
	}


	public int getQuantidade() {
		return quantidade;
	}


	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}


	public Double getPrecoItem() {
		return precoItem;
	}


	public void setPrecoItem(Double precoItem) {
		this.precoItem = precoItem;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descricaoFatura == null) ? 0 : descricaoFatura.hashCode());
		result = prime * result + ((numeroFatura == null) ? 0 : numeroFatura.hashCode());
		result = prime * result + ((precoItem == null) ? 0 : precoItem.hashCode());
		result = prime * result + quantidade;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fatura other = (Fatura) obj;
		if (descricaoFatura == null) {
			if (other.descricaoFatura != null)
				return false;
		} else if (!descricaoFatura.equals(other.descricaoFatura))
			return false;
		if (numeroFatura == null) {
			if (other.numeroFatura != null)
				return false;
		} else if (!numeroFatura.equals(other.numeroFatura))
			return false;
		if (precoItem == null) {
			if (other.precoItem != null)
				return false;
		} else if (!precoItem.equals(other.precoItem))
			return false;
		if (quantidade != other.quantidade)
			return false;
		return true;
	}

	
	@Override
	public String toString() {
		return "Fatura [numeroFatura=" + numeroFatura + ", descricaoFatura=" + descricaoFatura + ", quantidade="
				+ quantidade + ", precoItem=" + precoItem + " Total da Fatura = " + getTotalFatura() + "]";
	}


	/**
	 * 
	 * @return valor total da fatura
	 */
	public Double getTotalFatura() {
		Double valorTotal = (precoItem * quantidade);
		
		if (valorTotal < 0) {
			if (precoItem < 0) {
				precoItem = 0.0;
			}
			valorTotal = 0D;
			System.out.println("Seu valor total é: " + valorTotal + " R$");
			return valorTotal;
			
		}

		System.out.println("Seu valor total é: " + valorTotal + " R$");
		return valorTotal;
	}
	
}
