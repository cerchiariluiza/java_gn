package com.teste.projeto02;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Teste Realizado com jUnit" );
    }
}
