package com.teste.projeto01.model;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Carro implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String modelo;
	private String cor;
	private int ano;
	private Marca marca;
	private String chassi;
	private Proprietario proprietario;
	private int velocidadeMaxima;
	private int velocidadeAtual;
	private int numeroPortas;
	private boolean tetoSolar;
	private int numeroMachas;
	private int numeroMachaAtual;
	private boolean cambioAutomatico;
	private Double volumeCombustivel;

	
	
	

	public Carro(Proprietario proprietario) {
		super();
		this.proprietario = proprietario;
	}



	public String getModelo() {
		return modelo;
	}



	public void setModelo(String modelo) {
		this.modelo = modelo;
	}



	public String getCor() {
		return cor;
	}



	public void setCor(String cor) {
		this.cor = cor;
	}



	public int getAno() {
		return ano;
	}



	public void setAno(int ano) {
		this.ano = ano;
	}



	public Marca getMarca() {
		return marca;
	}



	public void setMarca(Marca marca) {
		this.marca = marca;
	}



	public String getChassi() {
		return chassi;
	}



	public void setChassi(String chassi) {
		this.chassi = chassi;
	}



	public Proprietario getProprietario() {
		return proprietario;
	}



	public void setProprietario(Proprietario proprietario) {
		this.proprietario = proprietario;
	}



	public int getVelocidadeMaxima() {
		return velocidadeMaxima;
	}



	public void setVelocidadeMaxima(int velocidadeMaxima) {
		this.velocidadeMaxima = velocidadeMaxima;
	}



	public int getVelocidadeAtual() {
		return velocidadeAtual;
	}



	public void setVelocidadeAtual(int velocidadeAtual) {
		this.velocidadeAtual = velocidadeAtual;
	}



	public int getNumeroPortas() {
		return numeroPortas;
	}



	public void setNumeroPortas(int numeroPortas) {
		this.numeroPortas = numeroPortas;
	}



	public boolean isTetoSolar() {
		return tetoSolar;
	}



	public void setTetoSolar(boolean tetoSolar) {
		this.tetoSolar = tetoSolar;
	}



	public int getNumeroMachas() {
		return numeroMachas;
	}



	public void setNumeroMachas(int numeroMachas) {
		this.numeroMachas = numeroMachas;
	}

	

	public int getNumeroMachaAtual() {
		return numeroMachaAtual;
	}



	public void setNumeroMachaAtual(int numeroMachaAtual) {
		this.numeroMachaAtual = numeroMachaAtual;
	}



	public boolean isCambioAutomatico() {
		return cambioAutomatico;
	}



	public void setCambioAutomatico(boolean cambioAutomatico) {
		this.cambioAutomatico = cambioAutomatico;
	}



	public Double getVolumeCombustivel() {
		return volumeCombustivel;
	}



	public void setVolumeCombustivel(Double volumeCombustivel) {
		this.volumeCombustivel = volumeCombustivel;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ano;
		result = prime * result + (cambioAutomatico ? 1231 : 1237);
		result = prime * result + ((chassi == null) ? 0 : chassi.hashCode());
		result = prime * result + ((cor == null) ? 0 : cor.hashCode());
		result = prime * result + ((marca == null) ? 0 : marca.hashCode());
		result = prime * result + ((modelo == null) ? 0 : modelo.hashCode());
		result = prime * result + numeroMachas;
		result = prime * result + numeroPortas;
		result = prime * result + ((proprietario == null) ? 0 : proprietario.hashCode());
		result = prime * result + (tetoSolar ? 1231 : 1237);
		result = prime * result + velocidadeAtual;
		result = prime * result + velocidadeMaxima;
		result = prime * result + ((volumeCombustivel == null) ? 0 : volumeCombustivel.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Carro other = (Carro) obj;
		if (ano != other.ano)
			return false;
		if (cambioAutomatico != other.cambioAutomatico)
			return false;
		if (chassi == null) {
			if (other.chassi != null)
				return false;
		} else if (!chassi.equals(other.chassi))
			return false;
		if (cor == null) {
			if (other.cor != null)
				return false;
		} else if (!cor.equals(other.cor))
			return false;
		if (marca == null) {
			if (other.marca != null)
				return false;
		} else if (!marca.equals(other.marca))
			return false;
		if (modelo == null) {
			if (other.modelo != null)
				return false;
		} else if (!modelo.equals(other.modelo))
			return false;
		if (numeroMachas != other.numeroMachas)
			return false;
		if (numeroPortas != other.numeroPortas)
			return false;
		if (proprietario == null) {
			if (other.proprietario != null)
				return false;
		} else if (!proprietario.equals(other.proprietario))
			return false;
		if (tetoSolar != other.tetoSolar)
			return false;
		if (velocidadeAtual != other.velocidadeAtual)
			return false;
		if (velocidadeMaxima != other.velocidadeMaxima)
			return false;
		if (volumeCombustivel == null) {
			if (other.volumeCombustivel != null)
				return false;
		} else if (!volumeCombustivel.equals(other.volumeCombustivel))
			return false;
		return true;
	}

	/**
	 * Método acelera até a velocidade máxima de 1 km/h em 1 km/h
	 */
	public void acelerarAteVelocidadeMaxima() {
		if (velocidadeMaxima >= velocidadeAtual) {
			
			for (int i = 0; i < velocidadeMaxima ; i++) {
				velocidadeAtual += 1;
				System.out.println("Acelerando - Sua velocidade atual é: " + velocidadeAtual + " km/h");
			}
		}
		 
		
	}
	
	/**
	 * Chame o método e acelere 1km/h; 
	 */
	public void acelerar() {
		
		if (velocidadeAtual <= velocidadeMaxima ) {
				velocidadeAtual += 1;
				System.out.println("Sua velocidade atual é: " + velocidadeAtual + " km/h");
		}
		 
		
	}
	
	
	/**
	 * Método freia, velocidade atual vai para 0
	 */
	public void freia() {
		
		if (velocidadeAtual <= 0) {
			System.out.println("Seu carro está parado");
		}else {
			for (int i = velocidadeAtual; i > 0 ; i--) {
				velocidadeAtual -= 1;
				System.out.println("Sua velocidade atual é: " + velocidadeAtual + " km/h");
			}
		}
		
		System.out.println("Sua velocidade atual após freiar é: " + velocidadeAtual + " km/h");
	}
	
	/**
	 * Método troca a marcha, necessário colocar a marchar no parametro
	 */
	public void trocarmarcha(int numeromarcha) {
		if (numeromarcha <=  numeroMachas) {
			
			numeroMachaAtual = numeromarcha;
			System.out.println("Sua marcha atual é: " + numeroMachaAtual + "ª, seu carro tem: " + numeroMachas + " marchas.");
		}else {
			System.out.println("Opss... marcha não existe ou número não condiz com o seu carro");
		}
		
	}
	
	
	public void _reduzMarcha(int reduzirnumeromarcha) {
		if (reduzirnumeromarcha <=  numeroMachaAtual) {
			
			numeroMachaAtual -= reduzirnumeromarcha;
			System.out.println("Sua marcha atual é: " + numeroMachaAtual + " você reduziu: " + reduzirnumeromarcha + " marchas.");
			if (numeroMachaAtual == 0) {
				System.out.println("Marcha atual Neutro");
			}
		}else {
			System.out.println("Opss... Barbeiro, reduza a marcha direito.");
		}
		
	}
	
	public void marchare() {
		if (velocidadeAtual != 0 ) {
			System.out.println("Amigão, seu carro está em movimento, se você der ré agora vai capotar. Sou inteligênte não irei permitir!");
		}else {
			System.out.println("Ré está engatada e ativa");
		}
	}
	
	/**
	 * Calcule a autonomia do seu carro, passe a quantidade de litros e quantos quilômetros foi rodado na viagem!
	 */
	public void autonomiaCarro(Double litros, Double quilometros) {		
		Double autonomia = (quilometros / litros);
		String valorFormatado = new DecimalFormat("#,##0.00").format(autonomia);
		System.out.println("Seu carro tem uma autonomia de: " + valorFormatado + " km/l ");
	}
	
	public void mostrarVolumeCombustivel() {
		System.out.println("O volume é: " + volumeCombustivel);
	}
	
}
