package com.teste.projeto01;

import com.teste.projeto01.model.Carro;
import com.teste.projeto01.model.Endereco;
import com.teste.projeto01.model.Marca;
import com.teste.projeto01.model.Proprietario;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	Endereco endereco = new Endereco();
    	endereco.setCep("83833410");
    	endereco.setRua("Rua Rio Oiapoque");
    	endereco.setBairro("Iguaçu II");
    	endereco.setCidade("Curitiba");
    	endereco.setEstado("Paraná");
    	endereco.setComplemento("Apartamento 05 Bloco 10");
        Proprietario proprietario = new Proprietario("Jhonatan", "10978254501", "8404252", endereco);
        proprietario.setDataNascimento("10/01/1996");
        
        Marca marca = new Marca();
        marca.setAnoLancamento("1878");
        marca.setCodigoId("151541sd5542132aassa");
        marca.setNome("Chevrolet");
        marca.setNrModelos("RIO2A18");
        
        Carro carro = new Carro(proprietario);
        carro.setAno(2020);
        carro.setModelo("Chevrolet Tracker");
        carro.setCor("Braco");
        carro.setChassi("502 8xAvgp KV Rs8885");
        carro.setVelocidadeMaxima(198);
        carro.setVelocidadeAtual(0);
        carro.setNumeroPortas(4);
        carro.setTetoSolar(true);
        carro.setNumeroMachas(5);
        carro.setNumeroMachaAtual(1);
        carro.setCambioAutomatico(false);
        carro.setVolumeCombustivel(55D);
        carro.setMarca(marca);
        carro.trocarmarcha(5);
        carro._reduzMarcha(5);
        carro.acelerarAteVelocidadeMaxima();
        carro.freia();
        carro.acelerar();
        carro.marchare();
        carro.autonomiaCarro(11d, 50d);
        carro.mostrarVolumeCombustivel();
   
        
    }
}
