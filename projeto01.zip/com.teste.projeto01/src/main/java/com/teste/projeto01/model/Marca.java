package com.teste.projeto01.model;

import java.io.Serializable;

public class Marca implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String nome;
	private String nrModelos;
	private String anoLancamento;
	private String codigoId;
	
	public Marca() {
		// TODO Auto-generated constructor stub
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNrModelos() {
		return nrModelos;
	}
	public void setNrModelos(String nrModelos) {
		this.nrModelos = nrModelos;
	}
	public String getAnoLancamento() {
		return anoLancamento;
	}
	public void setAnoLancamento(String anoLancamento) {
		this.anoLancamento = anoLancamento;
	}
	public String getCodigoId() {
		return codigoId;
	}
	public void setCodigoId(String codigoId) {
		this.codigoId = codigoId;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((anoLancamento == null) ? 0 : anoLancamento.hashCode());
		result = prime * result + ((codigoId == null) ? 0 : codigoId.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((nrModelos == null) ? 0 : nrModelos.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Marca other = (Marca) obj;
		if (anoLancamento == null) {
			if (other.anoLancamento != null)
				return false;
		} else if (!anoLancamento.equals(other.anoLancamento))
			return false;
		if (codigoId == null) {
			if (other.codigoId != null)
				return false;
		} else if (!codigoId.equals(other.codigoId))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (nrModelos == null) {
			if (other.nrModelos != null)
				return false;
		} else if (!nrModelos.equals(other.nrModelos))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Marca [nome=" + nome + ", nrModelos=" + nrModelos + ", anoLancamento=" + anoLancamento + ", codigoId="
				+ codigoId + "]";
	}
	
	
}
